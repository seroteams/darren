# Notes — 2026_Jun01_23-12-16357479
Ingo · UX Expert · Bi-weekly check-in

## Focus points
- [23:13:10] these sound too forma, to in human 
  1
  Communication quality with others and stakeholders
  Whether his communication with others is landing well enough for the leader role he expects.
  ✓

  2
  Career trajectory and next-level stretch
  Whether he still wants the leader position and what specific behaviors would prove readiness this quarter.
  ✓

  3
  Trust and expectations with cross-functional partners
  Whether stakeholders feel informed and heard, since leadership depends on managing relationships beyond UX delivery.
- [23:13:25] better

  Pick the ones you want to cover.

  1
  How his communication lands with others
  Notes say his work with others communication isn’t good enough, so clarify what’s missing and where it breaks down.
  ✓

  2
  Stakeholder trust and expectations management
  Whether he’s building trust across partners matters for an Expert UX role seeking leadership credibility.
  ✓

  3
  Career trajectory and next-level stretch
  Whether he’s seeing the leader position as the next step, and what concrete behaviors would demonstrate readiness.
  ✓

## Questioning
- [23:15:24] strange to ask about personal life and not something a biweekly would do, its not profesionsl 

  What's been the best part of your world outside of work lately?
- [23:15:49] this does not make snes eto ask this
  prefer, can you say more about what that means for you right now?
- [23:16:40] this does not feel like a possitive question. its off What's been slower or harder than it should have been?
- [23:17:16] repeated question "What's been slower or harder than it should have been?
  "
- [23:17:36] Again, this is so harsh "Where has your communication with others broken down most recently?
  "
- [23:18:02] "been tough speak, can you say more about what that means for you right now?
  " this does makle sense
- [23:18:26] this is not an interview so this question is stupdi "Where are you taking the lead without waiting for someone else?
  ":
- [23:19:11] such a strange quiestion to link to from the last "What would make this quarter clearly successful for you, in one sentence?
  "
